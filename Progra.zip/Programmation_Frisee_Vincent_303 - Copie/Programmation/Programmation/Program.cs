﻿using Progra_1;

class Program
{
    static void Main()
    {
        GameManager manager = new GameManager();
        manager.Run();
    }
}